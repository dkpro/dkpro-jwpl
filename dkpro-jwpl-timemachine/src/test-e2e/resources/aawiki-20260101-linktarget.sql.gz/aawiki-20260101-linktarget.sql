/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.29-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: dbstore1007.eqiad.wmnet    Database: aawiki
-- ------------------------------------------------------
-- Server version	10.11.13-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `linktarget`
--

DROP TABLE IF EXISTS `linktarget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `linktarget` (
  `lt_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lt_namespace` int(11) NOT NULL,
  `lt_title` varbinary(255) NOT NULL,
  PRIMARY KEY (`lt_id`),
  UNIQUE KEY `lt_namespace_title` (`lt_namespace`,`lt_title`)
) ENGINE=InnoDB AUTO_INCREMENT=348 DEFAULT CHARSET=binary ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linktarget`
--

/*!40000 ALTER TABLE `linktarget` DISABLE KEYS */;
INSERT INTO `linktarget` VALUES (2,4,'Community_Portal'),(3,4,'Administrators'),(5,3,'Node_ue'),(6,2,'Korg'),(9,2,'Davidcannon_(usurped)~aawiki'),(12,2,'Jvano~aawiki'),(14,3,'Rich_Farmbrough'),(15,2,'Diagraph01'),(16,2,'Chamdarae'),(17,2,'Sj'),(18,2,'Szoltys1990'),(19,2,'Incelemeelemani_(usurped)~aawiki'),(20,2,'Taichi'),(23,2,'Korg/monobook.js'),(25,2,'Jasonzhuocn'),(26,2,'PIP~aawiki'),(27,2,'Zigger'),(28,3,'Zigger'),(29,2,'Tim_Starling/Test'),(30,3,'Gangleri'),(31,2,'Gangleri'),(33,2,'Aurevilly'),(34,3,'Aurevilly'),(35,2,'Koavf'),(40,3,'Hkraiym~aawiki'),(41,3,'Dcljr'),(42,2,'Dcljr'),(43,2,'M7'),(44,2,'Gaudio_(usurped)'),(45,2,'Lothar'),(46,10,'Delete'),(47,2,'Sirius_Zwarts_Bot'),(48,2,'R._Koot~aawiki'),(49,3,'Diagraph01'),(50,2,'JethroT'),(51,2,'Aeæ~aawiki'),(52,2,'Hégésippe_Cormier'),(53,3,'Hégésippe_Cormier'),(54,2,'Andre_Engels'),(55,2,'Robbot'),(56,2,'Hégésippe'),(57,3,'Hégésippe'),(58,2,'Diamond~aawiki'),(59,3,'Diamond~aawiki'),(60,3,'Gaudio_(usurped)'),(61,2,'Qurqa~aawiki'),(62,2,'Vargenau'),(63,3,'Vargenau'),(64,3,'Daka'),(65,3,'82.161.83.69'),(66,2,'Daka'),(67,2,'CommonsDelinker'),(68,2,'Xandi'),(69,3,'M.M.S.'),(70,2,'Mr_Accountable'),(71,2,'Pill'),(72,2,'Pill/monobook.js'),(73,4,'Sandbox'),(74,2,'Tiyoringo'),(75,2,'JAnDbot'),(76,2,'Ev'),(77,2,'F~aawiki'),(78,3,'211.231.187.49'),(79,2,'Thijs!bot'),(80,2,'Escarbot'),(81,3,'Escarbot'),(82,2,'Thogo'),(83,2,'Az1568'),(84,3,'Az1568'),(85,2,'TXiKiBoT'),(86,3,'Bastique'),(87,2,'Bastique/sandbox'),(88,3,'Jasonzhuocn'),(89,2,'Kelovy'),(90,2,'Patrick'),(91,2,'GHe'),(92,3,'GHe'),(93,2,'ReyBrujo'),(94,2,'ReyBrujo/Dumps'),(95,2,'ReyBrujo/Dumps/20070206'),(96,2,'ReyBrujo/Styles/Header'),(97,2,'ReyBrujo/Styles/Footer'),(98,2,'Mithridates'),(99,2,'Brooke_Vibber'),(100,2,'ReyBrujo/Dumps/Archive'),(101,2,'ReyBrujo/Dumps/20070222'),(102,2,'ReyBrujo/Dumps/20070326'),(103,2,'ReyBrujo/Dumps/20070402'),(104,2,'ReyBrujo/Dumps/20070416'),(105,2,'ReyBrujo/Dumps/20070425'),(106,2,'VolkovBot'),(107,2,'EDUCA33E'),(108,2,'Picaroon9288'),(109,3,'Pathoschild'),(110,2,'Yosri'),(111,2,'Tximist'),(112,2,'Cbrown1023'),(113,2,'Jorunn'),(114,2,'Sandboxer5000~aawiki'),(115,2,'Majorly'),(116,2,'.snoopy.'),(117,3,'.snoopy.'),(118,3,'Purodha'),(119,2,'Purodha'),(120,4,'Protected_pages'),(121,2,'Siebrand'),(122,2,'SieBot'),(123,3,'SieBot'),(124,2,'MF-Warburg'),(125,2,'BotMultichill'),(126,3,'Multichill'),(127,2,'Multichill'),(128,3,'BotMultichill'),(129,3,'Deepak_agrawal'),(130,3,'PipepBot'),(131,2,'PipepBot'),(132,2,'EdmundEzekielMahmudIsa'),(133,10,'Babel'),(134,4,'Nospam'),(135,2,'Ooswesthoesbes'),(136,2,'Cometstyles'),(137,2,'Drini'),(138,3,'Jorunn'),(139,2,'DerHexer'),(140,2,'Scooter'),(141,2,'The_Rattlesnake~aawiki'),(142,3,'AlleborgoBot'),(143,2,'AlleborgoBot'),(144,2,'A~aawiki'),(145,2,'C~aawiki'),(146,3,'C~aawiki'),(147,2,'K~aawiki'),(148,3,'A~aawiki'),(149,2,'Q~aawiki'),(150,2,'Qafár'),(151,10,'User:P/Disc_frame'),(152,3,'Qafár'),(153,2,'H~aawiki'),(154,2,'Gangleri/monobook.js'),(155,10,'Style/IPA'),(157,10,'Style/yid'),(158,2,'Alexsh'),(159,2,'Erkan_Yilmaz'),(160,2,'Riana'),(161,2,'Charra_l\'aragonés'),(162,2,'Dungodung'),(163,2,'Nick1915'),(164,8,'Titleblacklist'),(165,2,'Alexbot'),(166,2,'Monobi'),(168,2,'Werdan7'),(169,3,'Werdan7'),(170,2,'Mike.lifeguard'),(171,3,'Mike.lifeguard'),(172,2,'Razorflame'),(173,3,'Alexbot'),(178,3,'Purbo_T'),(179,2,'Purbo_T'),(180,2,'Arcticocean'),(181,3,'Arcticocean'),(182,2,'Jj137'),(183,3,'Jj137'),(184,2,'Malafaya'),(185,2,'Alecs.bot'),(186,2,'Alecs.y'),(187,3,'Alexsh'),(188,3,'Alexsht'),(189,2,'Carkuni'),(190,2,'Riden'),(191,2,'Manecke'),(192,2,'EVula'),(193,2,'EVula/header'),(194,2,'DerHexer/monobook.js'),(195,2,'Afar_god'),(196,0,'Afar'),(197,2,'Rich_Farmbrough'),(198,2,'70.105.39.166'),(199,2,'Proofreader'),(200,2,'Platonides'),(201,2,'Eugrus'),(202,2,'Tim_Starling'),(203,2,'83.152.97.31'),(204,2,'Davidcannon'),(205,2,'Glitter'),(206,3,'Glitter'),(207,14,'User_aa'),(208,14,'User_aa-0'),(209,10,'Cc-by-sa-2.0'),(210,2,'Kanesue'),(211,2,'Meno25'),(212,14,'User_es'),(213,14,'User_es-2'),(214,14,'User_fr'),(215,14,'User_fr-1'),(216,14,'Wikipedians_by_language'),(217,3,'Spacebirdy'),(218,2,'PDD'),(219,2,'Max_sonnelid'),(220,3,'Max_sonnelid'),(221,2,'MelancholieBot'),(222,4,'Statistics'),(223,2,'Mike.lifeguard/monobook.js'),(224,3,'I'),(225,2,'I'),(226,2,'I_ät_de.wikt'),(227,3,'I_ät_de.wikt'),(228,3,'Hercule'),(229,4,'Babel'),(230,2,'Junafani'),(231,14,'User_en'),(232,14,'User_en-2'),(233,0,'Main_Page'),(234,2,'Johney'),(235,2,'Prevert'),(236,3,'Dethic'),(237,2,'MaxSem'),(238,2,'IAlex'),(239,2,'VIGNERON'),(240,3,'Legoktm'),(241,2,'ZorroIII'),(242,2,'E'),(243,2,'Dani'),(244,2,'Caiaffa'),(245,14,'User_en-3'),(246,14,'User_nl'),(247,14,'User_nl-N'),(248,2,'Anas1712'),(249,2,'Daniel'),(250,3,'Daniel'),(251,2,'TXiKi'),(252,2,'CarsracBot'),(253,2,'Moe_Epsilon'),(254,2,'StigBot'),(255,2,'YourEyesOnly'),(256,2,'Harrywad'),(257,3,'Beetstra'),(258,14,'User_de'),(259,14,'User_de-1'),(260,2,'TottyBot'),(261,2,'Metsavend'),(262,2,'Marbot'),(263,3,'Marbot'),(264,14,'User_sk'),(265,14,'User_sk-N'),(266,2,'MenoBot'),(267,2,'Edward_the_Confessor'),(268,2,'Playtime'),(269,2,'Matasg'),(270,3,'MenoBot'),(271,2,'Pwjb'),(272,2,'Ozi64'),(273,2,'Gondnok'),(274,2,'Beetstra'),(275,2,'Law_soma'),(276,2,'Hercule/Editcounter'),(277,2,'כל_יכול'),(278,2,'WikiDreamer'),(279,3,'WikiDreamer'),(280,8,'Sitenotice'),(281,2,'Oscar'),(282,3,'Meno25'),(283,8,'Configuredpages-def-stable'),(284,8,'Flaggedrevs'),(285,8,'Flaggedrevs-backlog'),(286,8,'Flaggedrevs-desc'),(287,8,'Flaggedrevs-prefs-editdiffs'),(288,8,'Flaggedrevs-prefs-stable'),(289,8,'Flaggedrevs-prefs-viewdiffs'),(290,8,'Flaggedrevs-protect-autoconfirmed'),(291,8,'Flaggedrevs-protect-legend'),(292,8,'Flaggedrevs-protect-none'),(293,8,'Flaggedrevs-protect-review'),(294,8,'Flaggedrevs-watched-pending'),(295,8,'Oldreviewed-stable'),(296,8,'Prefs-flaggedrevs'),(297,8,'Prefs-flaggedrevs-ui'),(298,8,'Review-diff2stable'),(299,8,'Review-edit-diff'),(300,8,'Review-logentry-app'),(301,8,'Review-logentry-dis'),(302,8,'Review-logpagetext'),(303,8,'Revreview-accuracy-0'),(304,8,'Revreview-basic'),(305,8,'Revreview-basic-i'),(306,8,'Revreview-basic-old'),(307,8,'Revreview-basic-same'),(308,14,'User_fr-N'),(309,8,'Revreview-basic-source'),(310,8,'Revreview-basic-title'),(311,8,'Revreview-check-flag'),(312,8,'Revreview-def-stable'),(313,8,'Revreview-depth-0'),(314,8,'Revreview-diff-toggle-title'),(315,8,'Revreview-draft-title'),(316,8,'Revreview-edited'),(317,8,'Revreview-editnotice'),(318,8,'Revreview-filter-approved'),(319,8,'Revreview-filter-reapproved'),(320,8,'Revreview-filter-stable'),(321,14,'User_he'),(322,14,'User_he-N'),(323,8,'Revreview-filter-unapproved'),(324,8,'Revreview-hist-basic'),(325,8,'Revreview-hist-basic-auto'),(326,8,'Revreview-hist-basic-user'),(327,8,'Revreview-hist-draft'),(328,8,'Revreview-lev-basic'),(329,8,'Revreview-locked'),(330,8,'Revreview-locked-title'),(331,8,'Revreview-log-details-title'),(332,8,'Revreview-log-toggle-hide'),(333,8,'Revreview-log-toggle-show'),(334,8,'Revreview-newest-basic'),(335,8,'Revreview-newest-basic-i'),(336,8,'Revreview-newest-quality'),(337,8,'Revreview-newest-quality-i'),(338,14,'Articles'),(339,14,'Wikipedia'),(340,14,'Top_Level'),(341,14,'User_templates_nl'),(342,14,'User_templates_de'),(343,14,'User_templates_fr'),(344,14,'Language_user_templates'),(345,14,'Userboxes'),(346,14,'User_templates_en'),(347,14,'Candidates_for_speedy_deletion');
/*!40000 ALTER TABLE `linktarget` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-01 13:22:16
